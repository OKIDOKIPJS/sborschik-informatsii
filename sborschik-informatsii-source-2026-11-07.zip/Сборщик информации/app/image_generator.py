"""Generate and review a deterministic, text-only summary image for MAX."""
from __future__ import annotations

import hashlib
import re
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from .config import DATA_DIR
from .logs import now_iso
from .review_queue import _assert_editable, _audit, get_draft

MOSCOW = timezone(timedelta(hours=3))
WIDTH, HEIGHT = 1200, 630


def _font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    candidates = []
    if Path("C:/Windows/Fonts").is_dir():
        candidates += [Path("C:/Windows/Fonts/segoeuib.ttf" if bold else "C:/Windows/Fonts/segoeui.ttf"),
                       Path("C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf")]
    candidates += [Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else
                         "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")]
    for candidate in candidates:
        if candidate.is_file():
            return ImageFont.truetype(str(candidate), size=size)
    raise RuntimeError("Не найден шрифт с поддержкой кириллицы для карточки")


def _wrap(draw: ImageDraw.ImageDraw, text: str, font: ImageFont.FreeTypeFont,
          max_width: int, max_lines: int) -> list[str]:
    words = text.split()
    lines: list[str] = []
    line = ""
    while words:
        word = words.pop(0)
        candidate = f"{line} {word}".strip()
        if draw.textbbox((0, 0), candidate, font=font)[2] <= max_width:
            line = candidate
            continue
        if line:
            lines.append(line)
        line = word
        if len(lines) == max_lines:
            break
    if line and len(lines) < max_lines:
        lines.append(line)
    if words and lines:
        last = lines[-1]
        while last and draw.textbbox((0, 0), last + "…", font=font)[2] > max_width:
            last = last.rsplit(" ", 1)[0] if " " in last else last[:-1]
        lines[-1] = last.rstrip(" ,;:—-") + "…"
    return lines


def _image_text(title: str, body: str) -> tuple[str, str]:
    for line in body.splitlines():
        stripped = line.strip()
        if stripped.startswith("• **") and "** — " in stripped:
            status, claim = stripped[4:].split("** — ", 1)
            claim = re.sub(r"\s+", " ", claim).strip().rstrip(".")
            return status.strip(), claim or title
        if stripped.startswith("Исправленная информация:"):
            return "ИСПРАВЛЕНИЕ", stripped.split(":", 1)[1].strip() or title
    return "СВОДКА", title


def _render(title: str, body: str, created_at: str, output: Path) -> None:
    image = Image.new("RGB", (WIDTH, HEIGHT), (20, 42, 47))
    draw = ImageDraw.Draw(image)
    # A decorative abstract pattern; it deliberately contains no maps, units,
    # locations, weapons, or depictions of a real event.
    for y in range(HEIGHT):
        blend = y / HEIGHT
        color = (int(20 + 6 * blend), int(42 + 24 * blend), int(47 + 13 * blend))
        draw.line((0, y, WIDTH, y), fill=color)
    draw.rounded_rectangle((48, 48, 1152, 582), radius=28,
                           outline=(88, 133, 116), width=2)
    draw.ellipse((895, 75, 1235, 415), fill=(29, 66, 64))
    draw.ellipse((1000, 162, 1270, 432), fill=(39, 81, 73))
    label, headline = _image_text(title, body)
    draw.rounded_rectangle((92, 106, 465, 148), radius=18, fill=(222, 235, 220))
    draw.text((112, 115), label[:36], font=_font(20, True), fill=(27, 63, 53))

    try:
        local_date = datetime.fromisoformat(created_at.replace("Z", "+00:00")).astimezone(MOSCOW)
        date_label = "Проверено " + local_date.strftime("%d.%m.%Y · МСК")
    except (TypeError, ValueError):
        date_label = "Проверено " + datetime.now(MOSCOW).strftime("%d.%m.%Y · МСК")
    draw.text((92, 180), date_label, font=_font(20), fill=(190, 210, 199))

    headline = " ".join(headline.split()) or "Сообщения о ситуации"
    title_font = _font(42, True)
    lines = _wrap(draw, headline, title_font, 980, 4)
    y = 236
    for line in lines:
        draw.text((92, y), line, font=title_font, fill=(248, 250, 246))
        y += 65
    draw.line((92, 510, 1108, 510), fill=(87, 128, 112), width=2)
    draw.text((92, 531), "Материалы по открытым источникам · редакторская сводка",
              font=_font(19), fill=(190, 210, 199))
    output.parent.mkdir(parents=True, exist_ok=True)
    image.save(output, format="PNG", optimize=True)


def _body_hash(body: str) -> str:
    return hashlib.sha256(body.encode("utf-8")).hexdigest()


def image_file(row: sqlite3.Row | dict) -> Path:
    file_name = str(row["file_name"])
    if Path(file_name).name != file_name or not file_name.startswith("draft-") or not file_name.endswith(".png"):
        raise ValueError("Некорректное имя файла карточки")
    return (DATA_DIR / "generated_images" / file_name).resolve()


def current_image(db: sqlite3.Connection, draft: sqlite3.Row | dict,
                  *, verify_file: bool = True) -> sqlite3.Row | None:
    row = db.execute(
        """SELECT * FROM draft_images WHERE draft_id=? AND body_hash=?
           ORDER BY id DESC LIMIT 1""",
        (draft["id"], _body_hash(draft["body"])),
    ).fetchone()
    if row and verify_file:
        path = image_file(row)
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != row["content_hash"]:
            return None
    return row


def image_for_revision(db: sqlite3.Connection, draft_id: int, revision: int) -> sqlite3.Row | None:
    draft = get_draft(db, draft_id)
    if draft["revision"] != revision:
        return None
    return current_image(db, draft)


def generate_image(db: sqlite3.Connection, draft_id: int,
                   expected_revision: int | None = None) -> dict[str, object]:
    db.execute("BEGIN IMMEDIATE")
    try:
        draft = _assert_editable(db, draft_id, expected_revision)
        body_hash = _body_hash(draft["body"])
        generation_no = int(db.execute(
            "SELECT COALESCE(MAX(generation_no),0)+1 FROM draft_images WHERE draft_id=? AND draft_revision=?",
            (draft_id, draft["revision"]),
        ).fetchone()[0])
        file_name = f"draft-{draft_id}-r{draft['revision']}-g{generation_no}.png"
        path = (DATA_DIR / "generated_images" / file_name).resolve()
        root = (DATA_DIR / "generated_images").resolve()
        if path.parent != root:
            raise ValueError("Недопустимый путь для изображения")
        _render(str(draft["title"]), str(draft["body"]), str(draft["created_at"]), path)
        content_hash = hashlib.sha256(path.read_bytes()).hexdigest()
        created_at = now_iso()
        image_id = int(db.execute(
            """INSERT INTO draft_images(draft_id,draft_revision,generation_no,body_hash,file_name,
               content_hash,status,generated_at) VALUES(?,?,?,?,?,?,'pending',?)""",
            (draft_id, draft["revision"], generation_no, body_hash, file_name, content_hash, created_at),
        ).lastrowid)
        _audit(db, "draft_image_generated", "draft_image", image_id, {
            "draft_id": draft_id, "revision": draft["revision"], "file_name": file_name,
            "sha256": content_hash, "width": WIDTH, "height": HEIGHT,
        })
        db.commit()
        return {"status": "generated", "image_id": image_id, "revision": draft["revision"],
                "url": f"/api/drafts/{draft_id}/image?revision={draft['revision']}"}
    except Exception as exc:
        db.rollback()
        # The failed generation is still useful to the editor's audit trail.
        try:
            _audit(db, "draft_image_generation_failed", "draft", draft_id,
                   {"error": f"{type(exc).__name__}: {exc}"})
            db.commit()
        except sqlite3.Error:
            db.rollback()
        raise


def review_image(db: sqlite3.Connection, draft_id: int, approve: bool, note: str,
                 expected_revision: int | None = None) -> None:
    note = note.strip()
    if len(note) < 8 or len(note) > 1000:
        raise ValueError("Укажите, что именно проверено на изображении (8–1000 символов)")
    db.execute("BEGIN IMMEDIATE")
    try:
        draft = _assert_editable(db, draft_id, expected_revision)
        image = current_image(db, draft)
        if image is None:
            raise ValueError("Для текущей версии текста сначала создайте изображение заново")
        status = "approved" if approve else "rejected"
        reviewed_at = now_iso()
        db.execute("UPDATE draft_images SET status=?,review_note=?,reviewed_at=? WHERE id=?",
                   (status, note, reviewed_at, image["id"]))
        _audit(db, "draft_image_reviewed", "draft_image", image["id"], {
            "draft_id": draft_id, "revision": draft["revision"], "status": status, "note": note,
            "content_hash": image["content_hash"],
        })
        db.commit()
    except Exception:
        db.rollback()
        raise


def set_media_token(db: sqlite3.Connection, image_id: int, token: str) -> None:
    if not token or len(token) > 4096:
        raise ValueError("MAX вернул некорректный токен изображения")
    db.execute("BEGIN IMMEDIATE")
    try:
        image = db.execute("SELECT draft_id,content_hash FROM draft_images WHERE id=?", (image_id,)).fetchone()
        if image is None:
            raise ValueError("Не найдено изображение для сохранения токена MAX")
        changed = db.execute("UPDATE draft_images SET max_media_token=? WHERE id=?", (token, image_id)).rowcount
        if changed != 1:
            raise ValueError("Не найдено изображение для сохранения токена MAX")
        _audit(db, "draft_image_uploaded", "draft_image", image_id,
               {"draft_id": image["draft_id"], "status": "uploaded", "token_saved": True,
                "content_hash": image["content_hash"]})
        db.commit()
    except Exception:
        db.rollback()
        raise
