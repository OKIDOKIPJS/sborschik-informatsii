@echo off
setlocal
cd /d "%~dp0"

set "PYTHON=%~dp0.venv\Scripts\python.exe"
set "EDITOR_URL=http://127.0.0.1:8765/"

if not exist "%PYTHON%" (
    echo Не найдено виртуальное окружение: "%PYTHON%"
    echo Откройте START.md и выполните шаги первичной настройки.
    pause
    exit /b 1
)

"%PYTHON%" -c "import urllib.request; urllib.request.urlopen('%EDITOR_URL%', timeout=1).read(1)" >nul 2>&1
if not errorlevel 1 (
    start "" "%EDITOR_URL%"
    exit /b 0
)

"%PYTHON%" -m app web --host 127.0.0.1 --port 8765 --open
if errorlevel 1 (
    echo.
    echo Кабинет завершился с ошибкой. Проверьте сообщение выше и раздел «Если не запускается» в START.md.
    pause
)

endlocal
